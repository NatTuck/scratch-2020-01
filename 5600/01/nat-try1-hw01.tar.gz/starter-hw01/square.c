long
square(long number)
{
    return 11 * number;
}
